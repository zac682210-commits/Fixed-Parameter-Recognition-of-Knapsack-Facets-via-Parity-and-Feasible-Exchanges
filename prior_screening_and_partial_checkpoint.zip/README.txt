Research checkpoint and evidence package — 2026-10-13
Author: Zhiyan Lin. Intermediate findings, not a solution of MOR34.

Read mor_candidate_screening_20261013.txt for the Chinese screening report and output/pdf/mor34_checkpoint.pdf for the mathematical proof checkpoint. TeX source is beside the PDF.

Exact reproducibility (Python standard library only), from this directory:
  python verify_small_certificate.py
  python verify_dimension34.py
  python verify_component_records34.py
The last command reads the retained component_bound34_results.json, exhaustively rechecks its count profiles and exact rational rank, and verifies the validity embedding. It does not enumerate 2^36 original binary vectors.

Core outputs:
  six_variable_exact_result.json: 64 binary vectors; 33 feasible; 8 tight; augmented rank6 vs parity-anchor rank5; determinant -1.
  dimension_identity_exact_result.json: 600 exact checks, fixed seed341325.
  component_records_exact_result.json: 4 exact facet records with C>K.
The older parity_anchor_six_variable_certificate.json concerns a different lifted version. The final clean example is six_variable_exact_result.json with weights(5,8,3,3,3,3).

Exploratory scripts and output JSON files are retained as discovery history. They require numpy/scipy and use floating-point ranks. They do not prove a general component bound. Their loop counts, seeds and time limits are in the scripts. Do not conflate absence of random counterexamples with a theorem.
Observed environment: 3.12.14, numpy2.3.5, scipy1.17.0.
The theoretical fixed-dimension ILP oracle is NOT implemented or benchmarked here. The full FPT(K) recognition problem is NOT solved. The proof gives FPT(C), a different parameter.

Provenance:
Sources and hashes: sources/retrieval_manifest.json. Local copies are retained for review and reproducibility; original authors retain their rights.
GitHub main progress files were retrieved. Fresh branches/issues/PR/forks API requests were rate-limited; no complete all-branch novelty audit is claimed.
Existing methods used: feasible swaps from public34 progress note; rank-nullity; fixed-dimension integer programming; convex-prefix epigraphs (Bredereck et al., arXiv1709.02850v2, Theorems1–2).
Research, exposition and code were developed with substantial Codex assistance in this session. No external review, author contact or public submission.
