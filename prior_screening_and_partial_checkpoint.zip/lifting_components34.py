import random,json,time
rng=random.Random(341318);t0=time.monotonic();records=[];cases=0

def components(a,c,b,d):
 groups={v:sorted([i for i,x in enumerate(c) if x==v],key=lambda i:(a[i],i)) for v in sorted(set(c))}; comps=[]
 for v,ids in groups.items():
  cuts=[]
  for r,s in zip(ids,ids[1:]):
   dp=[10**12]*(d+1);dp[0]=0
   for i,(aa,cc) in enumerate(zip(a,c)):
    if i in (r,s):continue
    for t in range(d,cc-1,-1):dp[t]=min(dp[t],dp[t-cc]+aa)
   if v>d or dp[d-v]+a[s]>b:cuts.append((r,s))
  comps.append(1+len(cuts))
 return comps
for Kmax in [2,3,4,5,6]:
 best=0
 for it in range(500):
  d=rng.randrange(2,18);w=rng.randrange(3,15);b=w*d+rng.randrange(w);a=[w]*(d+1);c=[1]*(d+1);dp=[0]*(b+1)
  for aa,cc in zip(a,c):
   for cap in range(b,aa-1,-1):dp[cap]=max(dp[cap],dp[cap-aa]+cc)
  for step in range(40):
   allowed=[]
   for aa in range(1,b+1):
    cc=d-dp[b-aa]
    if cc>0 and (cc in c or len(set(c))<Kmax):allowed.append((aa,cc))
   if not allowed:break
   aa,cc=rng.choice(allowed);a.append(aa);c.append(cc)
   for cap in range(b,aa-1,-1):dp[cap]=max(dp[cap],dp[cap-aa]+cc)
  comp=components(a,c,b,d);cases+=1;C=sum(comp);K=len(set(c))
  if C>best:
   best=C;r=dict(Kmax=Kmax,K=K,C=C,n=len(a),a=a,c=c,b=b,d=d,component_sizes_by_coefficient=comp);records.append(r);print('RECORD',Kmax,K,C,len(a),time.monotonic()-t0,flush=True)
 print('K done',Kmax,cases,time.monotonic()-t0,flush=True)
json.dump(dict(cases=cases,seconds=time.monotonic()-t0,records=records),open('screen_mor_20261013/lifting_components34_results.json','w'),indent=2)
