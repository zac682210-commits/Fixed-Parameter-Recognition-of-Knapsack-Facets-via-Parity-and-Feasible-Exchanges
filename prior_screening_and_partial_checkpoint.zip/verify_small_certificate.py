"""Exact stand-alone verification; Python standard library only.
Run: python verify_small_certificate.py
"""
import itertools,json
from pathlib import Path
from exact_linear import rank,rref,determinant
outdir=Path(__file__).resolve().parent
a=[5,8,3,3,3,3];b=13;c=[2,2,1,1,1,1];d=4
X=list(itertools.product([0,1],repeat=6));V=[x for x in X if sum(u*v for u,v in zip(a,x))<=b]
assert all(sum(u*v for u,v in zip(c,x))<=d for x in V)
T=[x for x in V if sum(u*v for u,v in zip(c,x))==d]
expected=[(1,1,0,0,0,0),(0,0,1,1,1,1)]+[(1,0)+y for y in itertools.product([0,1],repeat=4) if sum(y)==2]
assert set(T)==set(expected)
A=[[1]+list(x) for x in T];assert rank(A)==6
ids=rref(list(map(list,zip(*A))))[1];basis=[T[i] for i in ids];AB=[[1]+list(x) for x in basis];cols=rref(AB)[1];det=determinant([[row[j] for j in cols] for row in AB]);assert det
Z={};sw=[];groups=[[0,1],[2,3,4,5]]
for x in T:
 z=tuple(sum(x[i] for i in I) for I in groups);p=tuple(int(k<z[0]) for k in range(2))+tuple(int(k<z[1]) for k in range(4));Z[z]=p
rep={}
for z,p in Z.items():
 q=tuple(x%2 for x in z);cost=sum(aa*xx for aa,xx in zip(a,p))
 if q not in rep or (cost,z)<rep[q][0]:rep[q]=((cost,z),p)
for I in groups:
 for r,s in itertools.combinations(I,2):
  if any(x[r]==0 and x[s]==1 for x in T):
   w=[0]*7;w[r+1]=1;w[s+1]=-1;sw.append(w)
B=[[1]+list(v[1]) for v in rep.values()]+sw;assert rank(B)==5
assert all(row[2]==0 for row in B)
result=dict(status='PASS',binary_vectors_checked=64,feasible_count=len(V),tight_count=len(T),a=a,b=b,c=c,d=d,tight_points=T,parity_representatives=[x[1] for x in rep.values()],swap_directions=sw,full_augmented_rank=6,anchor_augmented_rank=5,facet_basis=basis,minor_columns=cols,minor_determinant=str(det))
(outdir/'six_variable_exact_result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','binary_vectors_checked','feasible_count','tight_count','full_augmented_rank','anchor_augmented_rank','minor_determinant']}))
