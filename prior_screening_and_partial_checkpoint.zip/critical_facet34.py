import itertools,json,time,numpy as np
rng=np.random.default_rng(341316);t0=time.monotonic();checks=facets=disconnected=0;fails=[]
for K,lo,hi in [(3,8,20),(4,5,11),(5,3,8),(6,2,6),(7,2,5),(8,2,4)]:
 for it in range(2500):
  ns=rng.integers(lo,hi,K);gam=rng.choice(np.arange(1,35),K,replace=False);d=int(rng.integers(int(sum(gam)),int(ns@gam)))
  ZZ=np.array(list(itertools.product(*[range(int(s)+1) for s in ns[:-1]])),dtype=int);rem=d-ZZ@gam[:-1];mask=(rem>=0)&(rem<=gam[-1]*ns[-1])&(rem%gam[-1]==0);Z=np.column_stack([ZZ[mask],rem[mask]//gam[-1]])
  if len(Z)<2:continue
  aa=[np.sort(rng.integers(1,300,int(s))) for s in ns];prefix=[np.r_[0,np.cumsum(a)] for a in aa];costs=sum(F[Z[:,j]] for j,F in enumerate(prefix));n=int(sum(ns))
  # Global minimum budget that permits each adjacent inversion.
  cutbounds=[]
  for j,(a,s,F) in enumerate(zip(aa,ns,prefix)):
   bb=[]
   for r in range(s-1):
    other=np.delete(a,[r,r+1]);H=np.r_[10**9,int(a[r+1])+np.r_[0,np.cumsum(other)],10**9];bb.append(int(min(costs-F[Z[:,j]]+H[Z[:,j]])))
   cutbounds.append(bb)
  events=sorted(set(costs.tolist()+sum(cutbounds,[])))
  def quotient(b):
   mask=costs<=b;z=Z[mask];cs=costs[mask]
   if len(z)==0:return False,None,None,None,None
   Q=[];comps=[]
   for j,s in enumerate(ns):
    cuts=[0]+[r+1 for r,bb in enumerate(cutbounds[j]) if bb>b]+[int(s)];comps.append(cuts)
    for l,h in zip(cuts,cuts[1:]):Q.append(np.clip(z[:,j]-l,0,h-l))
   Q=np.column_stack([np.ones(len(z),dtype=int)]+Q);C=Q.shape[1]-1
   return int(np.linalg.matrix_rank(Q))==C,Q,z,cs,comps
  checks+=1
  left=0;right=len(events)-1
  if not quotient(events[right])[0]:continue
  facets+=1
  while left<right:
   mid=(left+right)//2
   if quotient(events[mid])[0]:right=mid
   else:left=mid+1
  b=events[left];_,Q,z,cs,comps=quotient(b);C=Q.shape[1]-1
  if C<=K:continue
  disconnected+=1;reps={}
  for k,v in enumerate(z):
   key=tuple(v%2)
   if key not in reps or (int(cs[k]),tuple(v))<(int(cs[reps[key]]),tuple(z[reps[key]])):reps[key]=k
  r2=int(np.linalg.matrix_rank(Q[list(reps.values())]))
  if r2<C:
   out=dict(K=K,ns=ns.tolist(),gam=gam.tolist(),a=[a.tolist() for a in aa],b=b,d=d,quotient_rank=r2,true_quotient_rank=C,components=comps,profiles=z.tolist(),costs=cs.tolist(),representatives=[z[k].tolist() for k in reps.values()]);fails.append(out);print('FAIL',json.dumps(out),flush=True);break
  if it%100==0:print('progress',K,it,checks,facets,disconnected,time.monotonic()-t0,flush=True)
 print('K',K,checks,facets,disconnected,time.monotonic()-t0,flush=True)
 if fails:break
json.dump(dict(checks=checks,facets=facets,disconnected=disconnected,seconds=time.monotonic()-t0,counterexamples=fails),open('screen_mor_20261013/critical_facet34_results.json','w'),indent=2)
