import itertools,json
from pathlib import Path
from exact_linear import rank
p=Path(__file__).resolve().parent
src=json.load(open(p/'component_bound34_results.json'));out=[]
for e in src['records']:
 ns=e['ns'];gam=e['gam'];aa=e['a'];d=e['d'];b=e['b'];F=[[0]+list(itertools.accumulate(a)) for a in aa]
 Z=[z for z in itertools.product(*[range(s+1) for s in ns]) if sum(g*x for g,x in zip(gam,z))==d and sum(f[x] for f,x in zip(F,z))<=b]
 assert set(Z)==set(map(tuple,e['profiles']))
 Q=[];C=0
 for j,(a,s,f) in enumerate(zip(aa,ns,F)):
  cuts=[0]
  for r in range(s-1):
   other=[a[t] for t in range(s) if t not in (r,r+1)];possible=False
   for z in Z:
    if 1<=z[j]<=s-1:
     val=sum(ff[x] for ff,x in zip(F,z))-f[z[j]]+a[r+1]+sum(other[:z[j]-1])
     if val<=b:possible=True;break
   if not possible:cuts.append(r+1)
  cuts.append(s)
  assert cuts==e['components'][j]
  C+=len(cuts)-1
  for lo,hi in zip(cuts,cuts[1:]):Q.append([min(max(z[j]-lo,0),hi-lo) for z in Z])
 A=[[1]+list(t) for t in zip(*Q)];r=rank(A);assert r==C==e['C']
 # Embedding by a_i=(b+1)*c_i+residual_i ensures validity and preserves T.
 M=b+1;ba=M*d+b;wa=[M*g+w for g,alist in zip(gam,aa) for w in alist];assert max(wa)<=ba
 out.append(dict(K=e['K'],C=C,n=sum(ns),number_of_profiles=len(Z),exact_quotient_augmented_rank=r,full_augmented_rank=sum(ns),validity_multiplier=M,capacity=ba,status='PASS'))
(p/'component_records_exact_result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
