import itertools,json,time,numpy as np
rng=np.random.default_rng(341310);results=[];checks=0;t0=time.monotonic()
for n in range(4,13):
 X=np.array(list(itertools.product([0,1],repeat=n)),dtype=np.int8)
 for it in range(400):
  K=int(rng.integers(2,min(n,5)+1));gam=rng.choice(np.arange(1,10),K,replace=False);c=rng.choice(gam,n)
  a=rng.integers(1,45,n);order=sorted(range(n),key=lambda i:(c[i],a[i]));a=a[order];c=c[order]
  b=int(rng.integers(int(max(a)),int(sum(a))+1));V=X[X@a<=b];d=int(max(V@c));T=V[V@c==d]
  if not len(T):continue
  ids=[np.flatnonzero(c==val) for val in sorted(set(c))];profiles={};sw=[]
  for x in T:
   z=tuple(int(sum(x[I])) for I in ids)
   p=np.zeros(n,dtype=int)
   for I,t in zip(ids,z):p[I[:t]]=1
   profiles[z]=p
  for I in ids:
   for r,s in itertools.combinations(I,2):
    if np.any((T[:,r]==0)&(T[:,s]==1)):
     v=np.zeros(n+1,dtype=int);v[r+1]=1;v[s+1]=-1;sw.append(v)
  reps={}
  for z,p in profiles.items():
   key=tuple(v%2 for v in z); cost=int(p@a)
   if key not in reps or (cost,z)<reps[key][0]:reps[key]=((cost,z),p)
  A=[np.r_[1,p] for _,p in reps.values()]+sw
  rank=int(np.linalg.matrix_rank(A));true=int(np.linalg.matrix_rank(np.column_stack([np.ones(len(T)),T])))
  checks+=1
  if rank<true:
   result=dict(n=n,a=a.tolist(),b=b,c=c.tolist(),d=d,rank=rank,true_rank=true,profiles=[list(z) for z in profiles],representatives=[list(q[0][1]) for q in reps.values()])
   results.append(result);print('FAIL',json.dumps(result),flush=True)
   if len(results)>=3:break
 if len(results)>=3:break
 print('n',n,'checks',checks,'seconds',time.monotonic()-t0,flush=True)
json.dump(dict(checks=checks,seconds=time.monotonic()-t0,counterexamples=results),open('screen_mor_20261013/parity34_results.json','w'),indent=2)
print('DONE',checks,time.monotonic()-t0,flush=True)
