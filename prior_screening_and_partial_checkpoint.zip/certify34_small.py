import json,itertools,math
from pathlib import Path
from exact_linear import rref,rank,nullspace,determinant
p=Path('screen_mor_20261013');e=dict(a=[[5,8],[3,3,3,3]],gam=[2,1],ns=[2,4],b=13,d=4)
a=e['a'];gam=e['gam'];ns=e['ns'];b=e['b'];d=e['d'];offsets=[0]
for s in ns:offsets.append(offsets[-1]+s)
n=offsets[-1];prefix=[[0]+list(itertools.accumulate(v)) for v in a];Z=[z for z in itertools.product(*[range(s+1) for s in ns]) if sum(g*t for g,t in zip(gam,z))==d and sum(F[t] for F,t in zip(prefix,z))<=b]
def vec(z):return [int(i<t) for s,t in zip(ns,z) for i in range(s)]
def cost(z):return sum(F[t] for F,t in zip(prefix,z))
reps={}
for z in Z:
 key=tuple(t%2 for t in z)
 if key not in reps or (cost(z),z)<(cost(reps[key]),reps[key]):reps[key]=z
swapdirs=[];witnesses=[]
for j,s in enumerate(ns):
 for r,t in itertools.combinations(range(s),2):
  others=sorted([k for k in range(s) if k not in [r,t]],key=lambda k:(a[j][k],k))
  for z in Z:
   if not 1<=z[j]<=s-1:continue
   w=vec(z);w[offsets[j]:offsets[j+1]]=[int(k==t or k in others[:z[j]-1]) for k in range(s)]
   aw=sum(aa*xx for v in a for aa,xx in []) if False else sum(aa*xx for aa,xx in zip(sum(a,[]),w))
   if aw<=b:
    w2=w.copy();w2[offsets[j]+r]=1;w2[offsets[j]+t]=0
    v=[0]*(n+1);v[1+offsets[j]+r]=1;v[1+offsets[j]+t]=-1
    swapdirs.append(v);witnesses.extend([w,w2]);break
A=[[1]+vec(z) for z in Z]+swapdirs;B=[[1]+vec(z) for z in reps.values()]+swapdirs
ra=rank(A);rb=rank(B);normal=[-d]+[g for g,s in zip(gam,ns) for _ in range(s)]
extra=next(w for w in nullspace(B) if any(sum(x*y for x,y in zip(row,w)) for row in A))
points=list(dict.fromkeys(tuple(vec(z)) for z in Z))+list(dict.fromkeys(tuple(w) for w in witnesses));T=[[1]+list(w) for w in points];inds=rref(list(map(list,zip(*T))))[1];basis=[list(points[i]) for i in inds];TB=[[1]+w for w in basis];cols=rref(TB)[1];det=int(determinant([[row[c] for c in cols] for row in TB]));M=b+1;lift_a=[M*g+aa for g,v in zip(gam,a) for aa in v];lift_b=M*d+b
assert ra==n and rb==n-1 and len(basis)==n and det!=0
assert all(sum(ai*xi for ai,xi in zip(lift_a,x))<=lift_b and sum(ci*xi for ci,xi in zip(normal[1:],x))==d for x in basis)
out=dict(description='Six-variable exact counterexample to minimum-weight parity-profile anchors plus all feasible within-class swaps as a facet rank test',n=n,K=len(ns),coefficient_classes=gam,class_sizes=ns,residual_weights=a,residual_budget=b,rhs=d,lifting_multiplier=M,knapsack_weights=lift_a,knapsack_capacity=lift_b,profiles=[list(z) for z in Z],profile_costs=[cost(z) for z in Z],parity_representatives=[list(z) for z in reps.values()],swap_directions=swapdirs,full_augmented_rank=ra,anchor_augmented_rank=rb,extra_annihilator=extra,annihilator_on_profiles=[sum(q*v for q,v in zip(extra,[1]+vec(z))) for z in Z],facet_basis=basis,minor_columns=list(cols),minor_determinant=det)
json.dump(out,open(p/'parity_anchor_six_variable_certificate.json','w'),indent=2)
print(json.dumps({k:out[k] for k in ['n','K','knapsack_weights','knapsack_capacity','full_augmented_rank','anchor_augmented_rank','extra_annihilator','annihilator_on_profiles','minor_determinant']},indent=2))
