import json,urllib.request,concurrent.futures,subprocess,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
idx=json.load(open('screen_mor/index.json'))['problems']
tree=json.load(open('screen_mor/tree.json'))['tree']
nums={34,36,95,100,114,122,128,138,149}
base='https://raw.githubusercontent.com/AI-in-Math-OR/open-problems-in-or/main/'
tasks=[]
for d in idx:
 if d['number'] not in nums:continue
 tasks.append((base+'data/llm_math_export/'+d['path'],p/'sources'/f"problem{d['number']}.json"))
 for t in tree:
  if d['problem_id'] in t['path'] and t['path'].endswith('.pdf'):
   tasks.append((base+t['path'],p/'sources'/f"progress_{d['number']}_{Path(t['path']).name}"))
def work(v):
 url,path=v
 try:
  raw=urllib.request.urlopen(url,timeout=20).read();path.write_bytes(raw)
  if path.suffix=='.pdf':subprocess.run(['pdftotext','-layout',str(path),str(path.with_suffix('.txt'))],check=True)
  return {'url':url,'file':path.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
 except Exception as e:return {'url':url,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:r=list(ex.map(work,tasks))
(p/'sources/retrieval_manifest.json').write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
