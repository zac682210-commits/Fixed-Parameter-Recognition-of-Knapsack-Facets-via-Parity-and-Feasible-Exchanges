import itertools,json,time,numpy as np
rng=np.random.default_rng(341312);checks=facets=0;t0=time.monotonic();fails=[]
for K in range(2,6):
 for it in range(2000):
  ns=rng.integers(2,8,K);gam=rng.choice(np.arange(1,8),K,replace=False)
  Z=np.array(list(itertools.product(*[range(int(s)+1) for s in ns])),dtype=int);d=int(rng.integers(int(sum(gam)),int(ns@gam)));Z=Z[Z@gam==d]
  if len(Z)<2:continue
  aa=[np.sort(rng.integers(1,30,int(s))) for s in ns];prefix=[np.r_[0,np.cumsum(a)] for a in aa]
  costs=sum(F[Z[:,j]] for j,F in enumerate(prefix));b=int(rng.integers(int(min(costs)),int(max(costs))+1));Z=Z[costs<=b];costs=costs[costs<=b]
  if len(Z)<2:continue
  n=int(sum(ns));offsets=np.r_[0,np.cumsum(ns)];P=np.concatenate([np.arange(s)[None,:]<Z[:,j,None] for j,s in enumerate(ns)],axis=1).astype(int)
  swaps=[]
  for j,(a,s,F) in enumerate(zip(aa,ns,prefix)):
   for r,t in itertools.combinations(range(s),2):
    other=np.delete(a,[r,t]);H=np.r_[10**9,int(a[t])+np.r_[0,np.cumsum(other)],10**9]
    if np.any(costs-F[Z[:,j]]+H[Z[:,j]]<=b):
     v=np.zeros(n+1,dtype=int);v[1+offsets[j]+r]=1;v[1+offsets[j]+t]=-1;swaps.append(v)
  allA=[np.r_[1,p] for p in P]+swaps;r1=int(np.linalg.matrix_rank(allA));checks+=1
  if r1!=n:continue
  facets+=1;reps={}
  for k,z in enumerate(Z):
   key=tuple(z%2)
   if key not in reps or (int(costs[k]),tuple(z))<(int(costs[reps[key]]),tuple(Z[reps[key]])):reps[key]=k
  repA=[np.r_[1,P[k]] for k in reps.values()]+swaps;r2=int(np.linalg.matrix_rank(repA))
  if r2<r1:
   out=dict(K=K,ns=ns.tolist(),gam=gam.tolist(),a=[a.tolist() for a in aa],b=b,d=d,rank=r2,true_rank=r1,profiles=Z.tolist(),costs=costs.tolist(),representatives=[Z[k].tolist() for k in reps.values()]);fails.append(out);print('FAIL',json.dumps(out),flush=True);break
 print(K,checks,facets,'seconds',time.monotonic()-t0,flush=True)
 if fails:break
json.dump(dict(checks=checks,facets=facets,seconds=time.monotonic()-t0,counterexamples=fails),open('screen_mor_20261013/parity_facet34_results.json','w'),indent=2)
