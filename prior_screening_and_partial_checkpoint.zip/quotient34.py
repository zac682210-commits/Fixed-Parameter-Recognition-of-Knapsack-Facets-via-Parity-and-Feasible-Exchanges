import itertools,json,time,numpy as np
rng=np.random.default_rng(3401314);t0=time.monotonic();checks=facets=disconnected=0;fails=[]
for K in [4,5,6,7,8]:
 for it in range(1500):
  ns=rng.integers(2,6,K);gam=rng.choice(np.arange(1,22),K,replace=False);d=int(rng.integers(int(sum(gam)),int(ns@gam)))
  ZZ=np.array(list(itertools.product(*[range(int(s)+1) for s in ns[:-1]])),dtype=int)
  rem=d-ZZ@gam[:-1];mask=(rem>=0)&(rem<=gam[-1]*ns[-1])&(rem%gam[-1]==0);Z=np.column_stack([ZZ[mask],rem[mask]//gam[-1]])
  if len(Z)<2:continue
  aa=[np.sort(rng.integers(1,100,int(s))) for s in ns];prefix=[np.r_[0,np.cumsum(a)] for a in aa];costs=sum(F[Z[:,j]] for j,F in enumerate(prefix));b=int(rng.integers(int(min(costs)),int(max(costs))+1));mask=costs<=b;Z=Z[mask];costs=costs[mask]
  if len(Z)<2:continue
  comps=[];Q=[]
  for j,(a,s,F) in enumerate(zip(aa,ns,prefix)):
   cuts=[0]
   for r in range(s-1):
    other=np.delete(a,[r,r+1]);H=np.r_[10**9,int(a[r+1])+np.r_[0,np.cumsum(other)],10**9]
    if not np.any(costs-F[Z[:,j]]+H[Z[:,j]]<=b):cuts.append(r+1)
   cuts.append(s);comps.append(cuts)
   for lo,hi in zip(cuts,cuts[1:]):Q.append(np.clip(Z[:,j]-lo,0,hi-lo))
  Q=np.column_stack([np.ones(len(Z),dtype=int)]+Q);C=Q.shape[1]-1;checks+=1
  r1=int(np.linalg.matrix_rank(Q))
  if r1!=C:continue
  facets+=1
  if C<=K:continue
  disconnected+=1;reps={}
  for k,z in enumerate(Z):
   key=tuple(z%2)
   if key not in reps or (int(costs[k]),tuple(z))<(int(costs[reps[key]]),tuple(Z[reps[key]])):reps[key]=k
  r2=int(np.linalg.matrix_rank(Q[list(reps.values())]))
  if r2<r1:
   out=dict(K=K,ns=ns.tolist(),gam=gam.tolist(),a=[a.tolist() for a in aa],b=b,d=d,quotient_rank=r2,true_quotient_rank=r1,components=comps,profiles=Z.tolist(),costs=costs.tolist(),representatives=[Z[k].tolist() for k in reps.values()]);fails.append(out);print('FAIL',json.dumps(out),flush=True);break
  if it%300==0:print('progress',K,it,checks,facets,disconnected,time.monotonic()-t0,flush=True)
 print('K',K,checks,facets,disconnected,time.monotonic()-t0,flush=True)
 if fails:break
json.dump(dict(checks=checks,facets=facets,disconnected=disconnected,seconds=time.monotonic()-t0,counterexamples=fails),open('screen_mor_20261013/quotient34_results.json','w'),indent=2)
