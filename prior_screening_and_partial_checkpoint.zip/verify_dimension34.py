import itertools,random,json,time
from pathlib import Path
from exact_linear import rank
rng=random.Random(341325);start=time.monotonic();checked=0
for n in range(3,9):
 X=list(itertools.product([0,1],repeat=n))
 for _ in range(100):
  a=[rng.randrange(1,25) for i in range(n)];c=[rng.randrange(1,5) for i in range(n)];b=rng.randrange(max(a),sum(a)+1);V=[x for x in X if sum(ai*xi for ai,xi in zip(a,x))<=b];d=max(sum(ci*xi for ci,xi in zip(c,x)) for x in V);T=[x for x in V if sum(ci*xi for ci,xi in zip(c,x))==d]
  groups=[sorted([i for i in range(n) if c[i]==v],key=lambda i:(a[i],i)) for v in sorted(set(c))]
  edges=[]
  for G in groups:
   for r,s in itertools.combinations(G,2):
    if any(x[r]==0 and x[s]==1 for x in T):edges.append((r,s))
  def comps(edges):
   parent=list(range(n))
   def root(i):
    while parent[i]!=i:i=parent[i]
    return i
   for r,s in edges:parent[root(r)]=root(s)
   return sorted([sorted([i for i in range(n) if root(i)==r]) for r in set(root(i) for i in range(n))])
  CC=comps(edges);adj=[(r,s) for G in groups for r,s in zip(G,G[1:]) if (r,s) in edges];assert CC==comps(adj)
  U=set(tuple(sum(x[i] for i in B) for B in CC) for x in T);expected=set()
  arrays=[sorted(a[i] for i in B) for B in CC]
  for u in itertools.product(*[range(len(B)+1) for B in CC]):
   if sum(c[B[0]]*t for B,t in zip(CC,u))==d and sum(sum(arr[:t]) for arr,t in zip(arrays,u))<=b:expected.add(u)
  assert expected==U
  direct=rank([[1]+list(x) for x in T])-1;projected=rank([[1]+list(u) for u in U])-1
  assert direct==n-len(CC)+projected
  checked+=1
result=dict(status='PASS',cases=checked,seed=341325,dimensions=[3,8],checks=['adjacent swaps give same components as all pairs','component prefix profiles equal direct image','exact rational affine-dimension identity'],elapsed_seconds=time.monotonic()-start)
Path(__file__).with_name('dimension_identity_exact_result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
