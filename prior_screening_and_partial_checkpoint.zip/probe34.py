import numpy as np,itertools,json,time
from scipy.spatial import ConvexHull
from fractions import Fraction
from math import lcm,gcd
rng=np.random.default_rng(34013); found=[]; checks=0
for n in [5,6,7,8]:
 X=np.array(list(itertools.product([0,1],repeat=n)),dtype=int)
 for it in range(50):
  a=np.sort(rng.integers(1,35,n));b=int(rng.integers(max(a),sum(a)))
  V=X[X@a<=b]; hull=ConvexHull(V)
  seen=set()
  for eq in hull.equations:
   if min(eq[:-1])<1e-7: continue
   ratios=[Fraction(float(t/eq[0])).limit_denominator(1000) for t in eq[:-1]]
   den=lcm(*[t.denominator for t in ratios]);c=tuple(int(t*den) for t in ratios)
   g=gcd(*c);c=tuple(v//g for v in c)
   if c in seen:continue
   seen.add(c);d=int(max(V@c));T=V[V@c==d]
   if np.linalg.matrix_rank(np.column_stack([np.ones(len(T)),T]))!=n:continue
   K=len(set(c));checks+=1
   comps=[]
   for val in sorted(set(c)):
    ids=[i for i in range(n) if c[i]==val]; cuts=[]
    for l,r in zip(ids,ids[1:]):
     if not np.any((T[:,l]==0)&(T[:,r]==1)):cuts.append((l,r))
    comps.append(len(cuts)+1)
   if sum(comps)>K:
    found.append(dict(a=a.tolist(),b=b,c=c,d=d,K=K,components=comps,tight=T.tolist()))
    print('FOUND',json.dumps(found[-1]),flush=True)
    if len(found)>=3:break
  if len(found)>=3:break
 if len(found)>=3:break
json.dump({'checks':checks,'found':found},open('screen_mor_20261013/probe34_results.json','w'),indent=2)
print('checks',checks,flush=True)
